from matanyone.inference.inference_core import InferenceCore
from matanyone.model.matanyone import MatAnyone
