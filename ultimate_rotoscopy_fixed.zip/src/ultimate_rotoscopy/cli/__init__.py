"""
Ultimate Rotoscopy CLI
======================

Command-line interface for professional rotoscopy workflows.
"""

from ultimate_rotoscopy.cli.roto_cli import cli, main

__all__ = ["cli", "main"]
